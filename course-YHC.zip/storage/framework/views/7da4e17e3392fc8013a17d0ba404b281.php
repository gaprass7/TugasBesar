<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>
        <?php if(empty($row->kursus->foto)): ?>
        <img src="<?php echo e(url('admin/img/noprofile.png')); ?>" alt="Profile" class="rounded-circle">
        <?php else: ?>
        <img src="<?php echo e(url('admin/img')); ?>/<?php echo e($row->kursus->foto); ?>" alt="Profile" class="rounded-circle">
        <?php endif; ?>
        <h2><?php echo e($row->kursus->judul); ?></h2>
        <p><?php echo e($row->kursus->deskripsi); ?></p>
        <p><?php echo e($row->kursus->durasi); ?></p>
        <p><?php echo e($row->materi); ?></p>
    </div>
</body>
</html><?php /**PATH E:\integrasi\course-YHC\resources\views/adminpage/pembelajaran/detail.blade.php ENDPATH**/ ?>