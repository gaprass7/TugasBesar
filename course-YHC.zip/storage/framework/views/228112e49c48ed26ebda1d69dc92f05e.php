

<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h2>Add Pembelajaran</h2>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url ('dashboard')); ?>">Dashboard </a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('pembelajaran')); ?>">Pembelajaran </a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(url('pembelajaran/create')); ?>">Add Data</a></li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-8">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Form Add Pembelajaran</h5><br>

                        <!-- Horizontal Form -->
                        <form method="POST" action="<?php echo e(route('pembelajaran.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="input-group input-group-static mb-4">
                                        <label>Judul Kursus</label>
                                        <div class="col-md-12">
                                            <select class="form-control" name="kursus_id">
                                                <option selected>-- Pilih Kursus --</option>
                                                <?php $__currentLoopData = $ar_kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->judul); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group input-group-static mb-4">
                                        <label>Judul Materi</label>
                                        <div class="col-md-12">
                                            <select class="form-control" name="materi_id">
                                                <option selected>-- Pilih Materi --</option>
                                                <?php $__currentLoopData = $ar_materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->judul); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="text-center">
                                    <button class="btn btn-danger">
                                        <a style="color:white;" title="Batal" href=" <?php echo e(url('pembelajaran')); ?>">Batal
                                        </a>
                                    </button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminpage.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\integrasi\course-YHC\resources\views/adminpage/pembelajaran/form.blade.php ENDPATH**/ ?>